# GTUC independent top-up store starter

This is a **development starter**, not a production-ready payment or game-diamond delivery service.

## Important brand and legal note
The storefront is intentionally labeled as an independent store and says it is not affiliated with or endorsed by Garena. Do not use Garena logos, claim official status, or sell/deliver game currency unless you have the required authorization and a legitimate supplier agreement. Consider choosing a distinct brand name to avoid customer confusion.

## Included
- Responsive storefront
- Diamond package list (sample prices are placeholders)
- Player UID validation and demo order creation
- SQLite database
- Admin login, order status management, package creation and enable/disable
- Basic security headers, login rate limiting, hashed admin password, session cookie settings

## Run locally
1. Install Node.js 20 or later.
2. Copy `.env.example` to `.env`.
3. Set a long random `SESSION_SECRET` and a unique strong `ADMIN_PASSWORD`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`; admin panel is at `/admin.html`.

## Before any public launch
- Replace the in-memory/default session store with a persistent production session store.
- Use HTTPS, secure secrets management, CSRF protection, audit logs, backups, monitoring and a production database.
- Add a verified payment gateway only after the account owner meets the provider's eligibility and compliance requirements. Never collect UPI PINs, OTPs, card PINs or game account passwords.
- Integrate only an authorized fulfilment provider and verify the exact player/account flow.
- Have an adult/business owner review payment, tax, consumer-protection, privacy and platform terms.
- Replace all sample prices with verified supplier pricing. Current sample amounts are not offers.
- Add customer support, refund/cancellation policy and privacy policy.

## Demo behavior
Checkout only creates a Pending order record. It does not take payment or deliver diamonds. The admin can update order status manually; marking an order Completed in this demo does not trigger fulfilment.
